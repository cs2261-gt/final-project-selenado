
//{{BLOCK(sky)

//======================================================================
//
//	sky, 512x256@4, 
//	+ 93 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x32 
//	Total size: 2976 + 4096 = 7072
//
//	Time-stamp: 2020-04-04, 18:31:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SKY_H
#define GRIT_SKY_H

#define skyTilesLen 2976
extern const unsigned short skyTiles[1488];

#define skyMapLen 4096
extern const unsigned short skyMap[2048];

#endif // GRIT_SKY_H

//}}BLOCK(sky)
